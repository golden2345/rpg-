import random as r

def NewFrame():
    print("\n" * 100)


mapline1 = ["[]","[]","[]","[]","[]","[]"]
mapline2 = ["[]"," *"," *"," *"," *","[]"]
mapline3 = ["[]"," *","[]","[]"," *","[]"]
mapline4 = ["[]"," *","[]","[]"," *","[]"]
mapline5 = ["[]"," *"," *"," *"," *","[]"]
mapline6 = ["[]"," *"," *"," *"," @","[]"]
mapline7 = ["[]","[]","[]","[]","[]","[]"]

mapIDline1 = ["0","0","0","0","0","0"]
mapIDline2 = ["0","0","0","0","0","0"]
mapIDline3 = ["0","0","0","0","0","0"]
mapIDline4 = ["0","0","0","0","0","0"]
mapIDline5 = ["0","0","0","0","0","0"]
mapIDline6 = ["0","0","0","0","0","0"]
mapIDline7 = ["0","0","0","0","0","0"]

def PrintMap():
    ml1 = "".join(mapline1)
    ml2 = "".join(mapline2)
    ml3 = "".join(mapline3)
    ml4 = "".join(mapline4)
    ml5 = "".join(mapline5)
    ml6 = "".join(mapline6)
    ml7 = "".join(mapline7)
    print(f"{ml1}\n{ml2}\n{ml3}\n{ml4}\n{ml5}\n{ml6}\n{ml7}")

def Move(Input):
    if Input == "ml":
        for x in range(6):
            if mapline1[x] == " @":
                if mapline1[x-1] == " *":
                    mapline1[x] = " *"
                    mapline1[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline2[x] == " @":
                if mapline2[x-1] == " *":
                    mapline2[x] = " *"
                    mapline2[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline3[x-1] == " *":
                    mapline3[x] = " *"
                    mapline3[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline4[x-1] == " *":
                    mapline4[x] = " *"
                    mapline4[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline5[x-1] == " *":
                    mapline5[x] = " *"
                    mapline5[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline6[x-1] == " *":
                    mapline6[x] = " *"
                    mapline6[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline7[x] == " @":
                if mapline7[x-1] == " *":
                    mapline7[x] = " *"
                    mapline7[x-1] = " @"
                    NewFrame()
                    PrintMap()
                    break
    elif Input == "mr":
        for x in range(6):
            if mapline1[x] == " @":
                if mapline1[x+1] == " *":
                    mapline1[x] = " *"
                    mapline1[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline2[x] == " @":
                if mapline2[x+1] == " *":
                    mapline2[x] = " *"
                    mapline2[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline3[x+1] == " *":
                    mapline3[x] = " *"
                    mapline3[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline4[x+1] == " *":
                    mapline4[x] = " *"
                    mapline4[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline5[x+1] == " *":
                    mapline5[x] = " *"
                    mapline5[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline6[x+1] == " *":
                    mapline6[x] = " *"
                    mapline6[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline7[x] == " @":
                if mapline7[x+1] == " *":
                    mapline7[x] = " *"
                    mapline7[x+1] = " @"
                    NewFrame()
                    PrintMap()
                    break
    elif Input == "md":
        for x in range(6):
            if mapline2[x] == " @":
                if mapline3[x] == " *":
                    mapline2[x] = " *"
                    mapline3[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline4[x] == " *":
                    mapline3[x] = " *"
                    mapline4[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline5[x] == " *":
                    mapline4[x] = " *"
                    mapline5[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline6[x] == " *":
                    mapline5[x] = " *"
                    mapline6[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
    elif Input == "mu":
        for x in range(6):
            if mapline3[x] == " @":
                if mapline2[x] == " *":
                    mapline3[x] = " *"
                    mapline2[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline3[x] == " *":
                    mapline4[x] = " *"
                    mapline3[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline4[x] == " *":
                    mapline5[x] = " *"
                    mapline4[x] = " @"
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline5[x] == " *":
                    mapline6[x] = " *"
                    mapline5[x] = " @"
                    NewFrame()
                    PrintMap()
                    break

class Franck:
    def EnterDamage(Damage):
        EnHp = open("NPCs\TestLocation\Franck.txt", "r").readlines()[0]
        math = int(EnHp) - 1
        Enemy = open("NPCs\TestLocation\Franck.txt", "w")
        Enemy.write(str(math))
        Enemy.write("\n")
        print("YEEESS")

class Attack:
    def Check(en):
        if en == "1e":
            Franck.EnterDamage(1)

def AttackCheck(inp):
    if inp == "al":
        for x in range(6):
            if mapline1[x] == " @":
                if mapline1[x-1] == "En":
                    Attack.Check(mapIDline1[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline2[x] == " @":
                if mapline2[x-1] == "En":
                    Attack.Check(mapIDline2[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline3[x-1] == "En":
                    Attack.Check(mapIDline3[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline4[x-1] == "En":
                    Attack.Check(mapIDline4[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline5[x-1] == "En":
                    Attack.Check(mapIDline5[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline6[x-1] == "En":
                    Attack.Check(mapIDline6[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline7[x] == " @":
                if mapline7[x-1] == "En":
                    Attack.Check(mapIDline7[x-1])
                    NewFrame()
                    PrintMap()
                    break
    if inp == "ar":
        for x in range(6):
            if mapline1[x] == " @":
                if mapline1[x+1] == "En":
                    Attack.Check(mapIDline1[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline2[x] == " @":
                if mapline2[x+1] == "En":
                    Attack.Check(mapIDline2[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline3[x+1] == "En":
                    Attack.Check(mapIDline3[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline4[x+1] == "En":
                    Attack.Check(mapIDline4[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline5[x+1] == "En":
                    Attack.Check(mapIDline5[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline6[x+1] == "En":
                    Attack.Check(mapIDline6[x-1])
                    NewFrame()
                    PrintMap()
                    break
            if mapline7[x] == " @":
                if mapline7[x+1] == "En":
                    Attack.Check(mapIDline7[x-1])
                    NewFrame()
                    PrintMap()
                    break
    if inp == "au":
        for x in range(6):
            if mapline2[x] == " @":
                if mapline1[x] == "En":
                    Attack.Check(mapIDline1[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline2[x] == "En":
                    Attack.Check(mapIDline2[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline3[x] == "En":
                    Attack.Check(mapIDline3[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline4[x-1] == "En":
                    Attack.Check(mapIDline4[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline5[x-1] == "En":
                    Attack.Check(mapIDline5[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline7[x] == " @":
                if mapline6[x] == "En":
                    Attack.Check(mapIDline6[x])
                    NewFrame()
                    PrintMap()
                    break
    if inp == "ad":
        for x in range(6):
            if mapline1[x] == " @":
                if mapline2[x] == "En":
                    Attack.Check(mapIDline2[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline2[x] == " @":
                if mapline3[x] == "En":
                    Attack.Check(mapIDline3[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline3[x] == " @":
                if mapline4[x] == "En":
                    Attack.Check(mapIDline4[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline4[x] == " @":
                if mapline5[x] == "En":
                    Attack.Check(mapIDline5[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline5[x] == " @":
                if mapline6[x] == "En":
                    Attack.Check(mapIDline6[x])
                    NewFrame()
                    PrintMap()
                    break
            if mapline6[x] == " @":
                if mapline7[x] == "En":
                    Attack.Check(mapIDline7[x])
                    NewFrame()
                    PrintMap()
                    break

while True:
    posline = r.randint(1, 7) 
    pos = r.randint(0, 5)
    if posline == 1 and mapline1[pos] == " *":
        mapline1[pos] = "En"
        mapIDline1[pos] = "1e"
        break
    elif posline == 2 and mapline2[pos] == " *":
        mapline2[pos] = "En"
        mapIDline2[pos] = "1e"
        break
    elif posline == 3 and mapline3[pos] == " *":
        mapline3[pos] = "En"
        mapIDline3[pos] = "1e"
        break
    elif posline == 4 and mapline4[pos] == " *":
        mapline4[pos] = "En"
        mapIDline4[pos] = "1e"
        break
    elif posline == 5 and mapline5[pos] == " *":
        mapline5[pos] = "En"
        mapIDline5[pos] = "1e"
        break
    elif posline == 6 and mapline6[pos] == " *":
        mapline6[pos] = "En"
        mapIDline6[pos] = "1e"
        break
    elif posline == 7 and mapline7[pos] == " *":
        mapline7[pos] = "En"
        mapIDline7[pos] = "1e"
        break

PrintMap()
open("NPCs\TestLocation\Franck.txt", "w").write("3")

while True:
    
    Input = input()
    
    if Input == "al" or Input == "ar" or Input == "au" or Input == "ad":
        AttackCheck(Input)
    
    elif Input == "ml" or Input == "mr" or Input == "mu" or Input == "md":
        Move(Input)

    
    
    else:
        print("Несуществует введённой команды")
    
    if int(open("NPCs\TestLocation\Franck.txt", "r").readlines()[0]) < 1:
        for x in range(6):
            if mapIDline6[x] == "1e":
                mapline6[x] = " *"
                mapIDline6[x] = "0"
                if Input == "al" or Input == "ar" or Input == "au" or Input == "ad":
                    NewFrame()
                    PrintMap()
                break
    
